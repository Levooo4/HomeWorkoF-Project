package hw2;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Sec extends JFrame{

    public Sec(String user,String password) {
        JButton b1=new JButton("done");
        JLabel l1=new JLabel("username:");
        JLabel l2=new JLabel("password:");
         JLabel l3=new JLabel(user);
        JLabel l4=new JLabel(password);
        setSize(400, 300);
        setLayout(new FlowLayout());
        setTitle("Show");
        add(l1);
        add(l3);
        add(l2);
        add(l4);
        add(b1);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
         
        setVisible(true);
    }
    
}
