package hw2;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;



public class HW2 extends JFrame{
 
    public HW2()  {
        JButton b1=new JButton("login");
        JButton b2=new JButton("clear");
        JButton b3=new JButton("exit");
        JLabel l1=new JLabel("username:");
        JLabel l2=new JLabel("password:");
        JTextField tf1=new JTextField(30);
        JPasswordField tf2=new JPasswordField(30);
        setSize(400, 300);
        FlowLayout fl=new FlowLayout();
        setLayout(fl);
        b1.setBackground(Color.GRAY);
        b2.setBackground(Color.green);
        b3.setBackground(Color.red);
   
        setTitle("Login");
        add(l1);
        add(tf1);
        add(l2);
        add(tf2);
        add(b1);
        add(b2);
        add(b3);
        
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user=tf1.getText();
                String pass=tf2.getText();
                Sec sec = new Sec(user,pass);
                setVisible(false);
            }
        });
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tf1.setText(""); tf2.setText("");
               
            }
        });
         b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        setVisible(true);
    }

    
    public static void main(String[] args) {
        new HW2();
    }
    
}
